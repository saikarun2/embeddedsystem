#include "rtc.h"
/*int main()
{
	PREINT = PREINT_VAL;
	PREFRAC = PREFRAC_VAL;
	CCR = 0x01;
	RTC_Init();
	InitLCD();
	while(1)
	{
		//start comment
		CmdLCD(0x80);
		U32LCD(HOUR);
		CharLCD(':');
		U32LCD(MIN);
		CharLCD(':');
		U32LCD(SEC);
		delay_ms(1000);
		//end coments

	     cmdlcd(0x80);
		CharLCD((HOUR/10)+48);
	CharLCD((HOUR%10)+48);
  CharLCD(':');
	CharLCD((MIN/10)+48);
		CharLCD((MIN%10)+48);
		CharLCD(':');
		CharLCD((SEC/10)+48);
	   CharLCD((SEC%10)+48);
	   CharLCD(0xC0);
		CharLCD((DOM/10)+48);
		CharLCD((DOM%10)+48);
		CharLCD('/');
		CharLCD((MONTH/10)+48);
    	CharLCD((MONTH%10)+48);
    	CharLCD('/');
	 CharLCD((YEAR/10)+48);
	CharLCD((YEAR%10)+48);
		delay_ms(1000);
	}
}*/
void RTC_Init(void)
{
	SEC = 00;
	MIN = 57;
	HOUR = 9;
	DOM = 1;
	MONTH = 6;
	YEAR = 23;	
	
	PREINT = PREINT_VAL;
	PREFRAC = PREFRAC_VAL;
	CCR = 0x01;
	//InitLCD();
/*	while(1)
	{
		   cmdlcd(0x80);
		CharLCD((HOUR/10)+48);
	CharLCD((HOUR%10)+48);
  CharLCD(':');
	CharLCD((MIN/10)+48);
		CharLCD((MIN%10)+48);
		CharLCD(':');
		CharLCD((SEC/10)+48);
	   CharLCD((SEC%10)+48);
	   CharLCD(0xC0);
		CharLCD((DOM/10)+48);
		CharLCD((DOM%10)+48);
		CharLCD('/');
		CharLCD((MONTH/10)+48);
    	CharLCD((MONTH%10)+48);
    	CharLCD('/');
	 CharLCD((YEAR/10)+48);
	CharLCD((YEAR%10)+48);
		delay_ms(1000);
	}*/
}
