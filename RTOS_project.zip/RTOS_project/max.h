void MAX30100_Init(void);
unsigned char MAX30100_ReadRegister(unsigned char val);
float MAX30100_ReadTemperature(void);
unsigned int * MAX30100_hb_spo2(void);

