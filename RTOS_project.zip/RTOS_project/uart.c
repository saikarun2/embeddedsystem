#include"uart.h"
char buff[200]="hello",dummy;
unsigned char i=0,ch,r_flag;

void UART0_Init()
{
	IODIR0|=1<<8;
	PINSEL0 = (TXD0_EN | RXD0_EN);
	U0LCR = (WORD_LEN_8 | STOP_BIT_1 | (1<<DLAB));
	U0DLL = DIVISOR;
	U0DLM = (DIVISOR>>8);
	U0LCR &= ~(1<<DLAB);	
	
	 #if UART_INT_ENABLE > 0

  VICIntSelect = 0x00000000; // IRQ
  VICVectAddr0 = (unsigned)UART0_isr;
  VICVectCntl0 = 0x20 | 6; /* UART0 Interrupt */
  VICIntEnable = 1 << 6;   /* Enable UART0 Interrupt */
 
  U0IER = 0x03;       /* Enable UART0 RX and THRE Interrupts */   
             
  #endif
						
}
void UART0_Tx_Char(char ch)
{
	U0THR = ch;
	while(((U0LSR>>TEMT_BIT)&1) == 0);
}
char UART0_Rx_Char(void)
{
	while(((U0LSR>>DR_BIT)&1) == 0);	
	return U0RBR;
}
void UART0_Tx_Str(char *ptr)
{
	while(*ptr != '\0')
		UART0_Tx_Char(*ptr++);
}

/*int main()
{
	char ch;
	UART0_Init();
	UART0_Tx_Str("UART0 Testing\r\n");
	while(1)
	{
		ch = UART0_Rx_Char();
		//delay_ms(3000);
		UART0_Tx_Str("Received character is: ");
		UART0_Tx_Char(ch);
    UART0_Tx_Str("\r\n");
	}
}*/

void UART0_isr(void) __irq
{
  if((U0IIR & 0x04)) //check if receive interrupt
  {
		//IOPIN0^=1<<8;
		ch = U0RBR;	/* Read to Clear Receive Interrupt */
		if(i<200)
			buff[i++] = ch; 
  }
  else
  {
      dummy=U0IIR; //Read to Clear transmit interrupt
  
  }
   VICVectAddr = 0; /* dummy write */
}


void UART0_Int(unsigned int n)
{
  unsigned char a[10]={0,0,0,0,0,0,0,0,0,0};
  int i=0;
  if(n==0)
  {
   UART0_Tx_Char('0');
		return;
  }
  else
  {
     while(n>0)
	 {
	   a[i++]=(n%10)+48;
	   n=n/10;
	 }
	 --i;
	 for(;i>=0;i--)
	 {
	  UART0_Tx_Char(a[i]);
	 }
   }
}

void UART0_Float(float f)
{
  int x;
  float temp;
  x=f;
  UART0_Int(x);
  UART0_Tx_Char('.');
  temp=(f-x)*100;
  x=temp;
  UART0_Int(x);
}
