#include<RTL.H>
#include<lpc21xx.h>
#include"string.h"
#include"types.h"
#include"lcd_defines.h"
#include"delays.h"
#include"max.h"
#include"uart.h"
#include"rtc.h"
#include"esp.h"
#include"i2c_eeprom.h"
#include"i2c.h"

#define STATUS_LED1 16
#define STATUS_LED2 17

/* id1, id2 will contain task identifications at run-time */
OS_TID id1, id2,id3;

//shared resource control
OS_MUT mutex1;  //taking 6the mutex for lcd
static unsigned short int prev;
unsigned int heartbeat,spo2,*data;
 f32 temperature;
 u32 temp_int;
//task declarations
__task void task2_rtc (void);
__task void task1_max (void);
__task void task3_esp (void);

typedef struct      
{                      
  unsigned char msgid;
	unsigned int flag;
} MSG_QUEUE;
os_mbx_declare (MsgQueue,1);             //Declare an RTX mailbox  for 1 messages
                                         /* Reserve a memory of sizeof(MSG_QUEUE) bytes each for 1 block. */
_declare_box (mpool,sizeof(MSG_QUEUE),1); /* Dynamic memory pool    */


int main()
{
    IODIR1 |= (1<<STATUS_LED1 | 1<<STATUS_LED2);
	InitLCD();
	UART0_Init();
	init_i2c();
	MAX30100_Init();
	RTC_Init();
	esp01_connectAP();
	//init_i2c();
	//MAX30100_Init();
	_init_box (mpool, sizeof(mpool),sizeof(MSG_QUEUE)); //initialize the 'mpool' memory for the membox dynamic allocation
  os_sys_init(task1_max);
}	
__task void task1_max (void)
{
  id1 = os_tsk_self ();                 // Obtain own system task identification number
  id2 = os_tsk_create (task2_rtc, 1);   //Assign system identification number of task2 to id2
  id3 = os_tsk_create (task3_esp, 1);           
	os_mut_init(&mutex1);
		
	for (;;) 
	{
		   //collecting values from max sensor
		temperature = MAX30100_ReadTemperature();
        temp_int = temperature;
		//data=MAX30100_hb_spo2();
		//heartbeat=*(data+1)<<8|*(data+0);   //heartbeat function return value;
		//spo2=*(data+2)<<8|*(data+3) ;   //spo2 function value
		os_mut_wait (&mutex1,0xffff);
		//cmdlcd(0x80);
		//strlcd("MAX_30100 activated");
		//delay_ms(1);
		cmdlcd(0x01);
	//	cmdlcd(0x80);
  //	strlcd("HB:");
		//cmdlcd(0x89);
		//U32LCD(heartbeat);
	//	cmdlcd(0x88);
	//	strlcd("SPO2:");
	//	cmdlcd(0xc5)
	//	U32LCD(spo2);
	//	cmdlcd(0xc0);
	cmdlcd(0x80);
		strlcd("TEMP: ");
		U32LCD(temp_int);
		os_mut_release(&mutex1);
		os_dly_wait (100);//wait on timer for 100 tick=100*10ms=1000ms
	}
}

__task void task2_rtc (void)
{
	MSG_QUEUE *sendptr;
	 
    os_mbx_init(MsgQueue, sizeof(MsgQueue));// initialize the mailbox  
	for (;;) 
	{
		os_mut_wait (&mutex1,0xffff);
		//cmdlcd(0x01);
        cmdlcd(0xc0);
		CharLCD((HOUR/10)+48);
        CharLCD((HOUR%10)+48);
        CharLCD(':');
        CharLCD((MIN/10)+48);
		CharLCD((MIN%10)+48);
		CharLCD(':');
		CharLCD((SEC/10)+48);
	   CharLCD((SEC%10)+48);
        os_mut_release(&mutex1);
		if(prev!=MIN)
		{
            
			sendptr=_alloc_box (mpool);//allocate the memory for the msg
			sendptr->flag=1;
			prev=MIN;
            os_mbx_send(MsgQueue,sendptr,0xffff);
		}
	}
}
__task void task3_esp (void)
{
	MSG_QUEUE *recvptr;
	for (;;)
	{
        IOPIN1 ^= 1<<STATUS_LED1;
        os_mbx_wait(MsgQueue,(void **)&recvptr,0xffff);
        IOPIN1 ^= 1<<STATUS_LED2;
        if(recvptr->flag==1)
        {
            esp01_sendToThingspeak(temp_int);
		  //esp01_sendToThingspeak(heartbeat);
	//	 esp01_sendToThingspeak(spo2);
            _free_box(mpool, recvptr);
        }
	}
}
