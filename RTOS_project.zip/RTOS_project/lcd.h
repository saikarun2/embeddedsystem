#include"types.h"
void cmdlcd(u8);
void CharLCD(u8);
void InitLCD(void);
void strlcd(s8 *);
void U32LCD(u32);
void s32lcd(s32);
void f32lcd(f32);
void buildcgram( u8*,u8);
