#include <LPC214x.h>

#include "i2c.h"
#include "types.h"
#include "delays.h"
#include "i2c_eeprom.h"

#define MAX30100_ADDR 0x57

#define MAX30100_REG_MODE_CONFIG    0x06  //register address
#define MAX30100_REG_TEMP_INT       0x16  
#define MAX30100_REG_TEMP_FRAC      0x17
#define MAX30100_REG_SPO2_CONFIG    0x07
#define MAX30100_REG_FIFO_DATA      0x05 //changed
#define MAX30100_LED_CONFIG         0x09

#define MAX30100_MODE_SPO2          0x02


void MAX30100_Init(void) 
{
  unsigned char val;

  i2c_eeprom_write(MAX30100_ADDR,MAX30100_REG_MODE_CONFIG,((0X03)|(1<<3))); //spo2,hb and temperatre enabled
  i2c_eeprom_write(MAX30100_ADDR,MAX30100_LED_CONFIG,0X8f); //27.1mA red 50 irled
  
  val = i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_FIFO_DATA); //reading value
	
  i2c_eeprom_write(MAX30100_ADDR,MAX30100_REG_FIFO_DATA,((val&0xFC)|(0x03)));  // bit 0 and 1 made xxxx xx11
	
  val = i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_FIFO_DATA);
	
  i2c_eeprom_write(MAX30100_ADDR,MAX30100_REG_FIFO_DATA,((val&0xe3)|(0x03<<2)));  //bit 2&3 made 1   xxxx 1111
  
  val = i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_FIFO_DATA);
	
  i2c_eeprom_write(MAX30100_ADDR,MAX30100_REG_FIFO_DATA,((val|(1<<6))));   //bit 6 made 1 
	                                                                        //fifo data now has xx1x 1111
	
}



unsigned char MAX30100_ReadRegister(unsigned char val)
{
    return i2c_eeprom_read(MAX30100_ADDR,val);
}


float MAX30100_ReadTemperature(void) 
{
    int temp, temp_int, temp_frac;
    float temperature;

    temp = i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_MODE_CONFIG);
    i2c_eeprom_write(MAX30100_ADDR,MAX30100_REG_MODE_CONFIG,((temp)|(1<<3)));
    if( !(i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_MODE_CONFIG) & ((1<<3))))
    {
        temp_int = i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_TEMP_INT);
        temp_frac = i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_TEMP_FRAC);
        temperature = temp_int + (0.0625*temp_frac);
        return temperature;
    }
    else
        return 0.0;
}

// check 
/*unsigned int * MAX30100_hb_spo2(void)
{
	unsigned int set_val,i=0;
	static unsigned int data[3];
	set_val=i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_MODE_CONFIG);
	i2c_eeprom_write(MAX30100_ADDR,MAX30100_REG_MODE_CONFIG,(set_val|0x03)); //sp02 enabled
	 delay_ms(1); //giving some delay for value generation
	for(i=0;i<4;i++)
	{
		 data[i]=i2c_eeprom_read(MAX30100_ADDR,MAX30100_REG_FIFO_DATA);
	}
	return data;
} */
