#include <lpc214x.h>
#include"lcd_defines.h"
#include"delays.h"


#define MAX30100_I2C_ADDRESS 0x57

void I2C_Init() {

 // Initialize I2C interface

 I2C0CONCLR = 0xFF; // Clear all I2C settings

 I2C0SCLL = 38; // Set SCL Low Time

 I2C0SCLH = 38; // Set SCL High Time

 I2C0CONSET = 0x40; // Enable I2C interface

}

void I2C_Start() {

 I2C0CONSET = 0x20; // Start I2C communication

 while (!(I2C0CONSET & 0x08)); // Wait until START transmitted

}
void I2C_Restart(void)
{
	I2C0CONSET=(1<<5);			// restart condition
	I2C0CONCLR = (1<<3);
	while(I2C0STAT!=0x10); //for restart condition transmitted
	I2C0CONCLR=(1<<5);			// clear start condition
}

void I2C_Stop() {

 I2C0CONSET = 0x10; // Stop I2C communication

 I2C0CONCLR = 0x08; // Clear START bit
	
while(((I2C0CONSET>>4)&1));//stop will cleared automatically

}

void I2C_Write(unsigned char data) {

 I2C0DAT = data; // Load data to be transmitted

 I2C0CONCLR = 0x28; // Clear SI and AA bits

 //while (!(I2C0CONSET & 0x08)); // Wait until data transmitted


	while(1)

  {		

		if(I2C0STAT==0x18) //slaveAddr+W transmitted with ack recvd

			 break;

    else if(I2C0STAT==0x20) //slaveAddr+W transmitted with no ack recvd

			break;

		else if(I2C0STAT==0x28)//buff addr/data transmitted with ack recvd

			 break;

    else if(I2C0STAT==0x30) //buff addr/data transmitted with no ack recvd

		   break;

		else if(I2C0STAT==0x40) //slaveAddr+r transmitted with ack recvd

			 break;

    else if(I2C0STAT==0x48) //slaveAddr+r transmitted with no ack recvd

			break;

	}

}	


unsigned char I2C_Read() {

 I2C0CONSET = 0x04; // Enable ACK

 I2C0CONCLR = 0x28; // Clear SI and AA bits

 while ((I2C0STAT!=0x50)); // Wait until data received
	
	I2C0CONCLR=0x04; //Clear Ack

 return I2C0DAT; // Return received data

}

unsigned char I2C_Read_Nack(void)
{
	I2C0CONSET=0x00;  //Assert Not of Ack
	I2C0CONCLR = (1<<3);
	while(I2C0STAT!=0x58);//data received,not of ack transmitted
	return I2C0DAT;
}	



void MAX30100_Init() {

 // Perform initialization sequence for MAX30100

 I2C_Start();

 I2C_Write(0xAE); // Send device address with write bit

 I2C_Write(0x00); // Write to configuration register

 I2C_Write(0x00); // Enable SpO2 mode, set sample rate to 100Hz
 I2C_Write(0x00); // 100 samples per s

 I2C_Write(0x00);
	 I2C_Write(0x00);
	 I2C_Write(0x00);
	 I2C_Write(0x00);
	 I2C_Write(0x03);
	 I2C_Write(0x00);
	 I2C_Write(0x00);
	 I2C_Write(0x33);


 I2C_Stop();

}
unsigned char I2C_Readbyte(unsigned char slaveAddr,unsigned char rBuffAddr)
{
	u8 dat;
  I2C_Start();
  I2C_Write(slaveAddr<<1); 	
  I2C_Write(rBuffAddr); 	
  I2C_Restart();	
	I2C_Write((slaveAddr<<1)|1);
	dat=I2C_Read_Nack();
	I2C_Stop();	
	return dat;
}

int MAX30100_ReadIR() {

 int n=0,i;
 unsigned char x;
 /*I2C_Start();

 I2C_Write(0XAF); //interupt reg reading

 I2C_Write(0x01);
  x=I2C_Read();
  while(!(x==0x30));*/



 I2C_Start();
 
 I2C_Write(0XAE); // Send device address with write bit

 I2C_Write(0x02); // send addr of FIFO_WR_PTR register

 I2C_Restart();

 I2C_Write(0XAF); // Send device address with read bit
 
 I2C_Read();
 
  I2C_Stop();


 I2C_Start();

 I2C_Write(0XAE); // Send device address with write bit

 I2C_Write(0x07); // Write to FIFO data register

 I2C_Restart();

 I2C_Write(0XAF); // Send device address with read bit


	 for(i=0;i<3;i++)

    { n=I2C_Read();

      n=n*10+n;
	 

     n=I2C_Read();//reading Data from RED LED  4-bytes

        n=n*10+n;
	 

     n=I2C_Read();
	 

       n=n*10+n;
	 delay_ms(5); 

     n=I2C_Read();

       n=n*10+n;
	 delay_ms(5);


      n=I2C_Read();

      n=n*10+n; 
	 delay_ms(5);

     n=I2C_Read();//reading Data from  IR LED  4-bytes

      n=n*10+n; 
	 delay_ms(5);

     n=I2C_Read();

      n=n*10+n;
	 delay_ms(5);

     n=I2C_Read();

      n=n*10+n;
	 delay_ms(5);

		}

		/*I2C_Stop();

		I2C_Start();

		I2C_Write(0XAE);

    I2C_Write(0X04); //send addr of RD_ptr

		I2C_Write(0X09);//write RD_ptr
		*/

		I2C_Stop();
	  return n;

    		

}

void I2C_DevSeqRead(u8 slaveAddr,u8 rBuffStartAddr,u8 *p,u8 nBytes)
{
	u8 i;
	I2C_Start();
  I2C_Write(slaveAddr<<1); 	
  I2C_Write(rBuffStartAddr); 	
  I2C_Restart();	
	I2C_Write((slaveAddr<<1)|1);
	for(i=0;i<nBytes-1;i++)
	{
		p[i]=I2C_Read();
	}
	p[i]=I2C_Read_Nack();
	I2C_Stop();
}

int main() {  int Value=0;

 PINSEL0 = 0x50; // Enable I2C pins

 I2C_Init(); // Initialize I2C interface
 InitLCD();

 MAX30100_Init(); // Initialize MAX30100

 CharLCD('H');

 

   Value = MAX30100_ReadIR(); // Read IR value
   U32LCD(Value);
   }
  




   

 

 