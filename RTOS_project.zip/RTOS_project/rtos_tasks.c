#include<RTL.H>
#include<lpc21xx.h>
#include"string.h"
#include"types.h"
#include"lcd_defines.h"
#include"delays.h"
#include"max.h"
#include"uart.h"
#include"rtc.h"
#include"esp.h"

/* id1, id2 will contain task identifications at run-time */
OS_TID id1, id2,id3;

//shared resource control
OS_MUT mutex1;  //taking 6the mutex for lcd

//task declarations
__task void task1_rtc (void);
__task void task2_max (void);
__task void task3_esp (void);

typedef struct      
{                      
  unsigned char msgid;
	unsigned int hr;
	unsigned int min;
	unsigned int sec;
	unsigned short int Heart_rate;
	unsigned short int O2_levels;
} MSG_QUEUE;
os_mbx_declare (MsgQueue,1);             //Declare an RTX mailbox  for 1 messages
                                         /* Reserve a memory of sizeof(MSG_QUEUE) bytes each for 1 block. */
_declare_box (mpool,sizeof(MSG_QUEUE),1); /* Dynamic memory pool    */


int main()
{
	InitLCD();
	UART0_Init();
	RTC_Init();
	I2C_Init();
	MAX30100_Init();
	_init_box (mpool, sizeof(mpool),sizeof(MSG_QUEUE)); //initialize the 'mpool' memory for the membox dynamic allocation
  os_sys_init(task1_rtc);
}	
__task void task1_rtc (void)
{
	unsigned int PREV;
	MSG_QUEUE *sendptr; 
  id1 = os_tsk_self ();                 // Obtain own system task identification number
  id2 = os_tsk_create (task2_max, 1);   //Assign system identification number of task2 to id2
  id3 = os_tsk_create (task3_esp, 1);
  os_mbx_init (MsgQueue, sizeof(MsgQueue));// initialize the mailbox             

	for (;;) 
	{
   	if(PREV+1==MIN)
	  {
			sendptr = _alloc_box (mpool);          // Allocate a memory for the message  
			sendptr->msgid=1;
			sendptr->hr=HOUR; 
			sendptr->min=MIN;
			sendptr->sec=SEC;
      sendptr->Heart_rate=0;
			sendptr->O2_levels=0;
			os_mbx_send (MsgQueue, sendptr, 0xffff);  // Send the message to the mailbox 
		
		  PREV=MIN;
		}//os_dly_wait (100);//wait on timer for 100 tick=100*10ms=1000ms
	}
}

__task void task2_max (void)
{
	MSG_QUEUE *recvptr;
	for (;;) 
	{
    os_mbx_wait(MsgQueue, (void **)&recvptr, 0xffff);
		//UART0_Tx_Str("Got Message with a msg id : ");
		os_mut_init(&mutex1);
		strlcd("Got Message with a msg id : ");
		CharLCD(recvptr->msgid);
	//  UART0_Tx_Str("\r\n Rxed Data is  : ");
		s32lcd(recvptr->hr);
		s32lcd(recvptr->min);
		s32lcd(recvptr->sec);
		//UART0_Tx_Str("\r\n");
		s32lcd(recvptr->Heart_rate=MAX30100_HEART_BEAT());
		s32lcd(recvptr->O2_levels=MAX30100_SPO2());
		     // free memory allocated for message 
		os_mut_release(&mutex1);
		os_mbx_send (MsgQueue,recvptr, 0xffff);
	}
}
__task void task3_esp (void)
{
	MSG_QUEUE *recvptr1;
	for (;;)
	{
		 os_mbx_wait(MsgQueue, (void **)&recvptr1, 0xffff);
		  esp01_sendToThingspeak(recvptr1->Heart_rate);
		 esp01_sendToThingspeak(recvptr1->O2_levels);
   	_free_box(mpool, recvptr1);
  }
}
