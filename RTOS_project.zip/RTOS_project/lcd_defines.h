#include"types.h"
#define LCD_DATA 8 //BYTE REQIRED
#define LCD_RS 16
#define LCD_RW 17
#define LCD_EN 18
#define GOTO_LINE1_POS0 0x80
#define GOTO_LINE2_POS0 0xc0
#define DISP_ON_CUR_OFF 0X0c
#define DISP_ON_CUR_ON 0X0E
#define DISP_ON_CUR_BLK 0X0F
#define SHF_CUR_RIGHT 0x06
#define CLR_DISP 0X01
#define CUR_HOME 0X02

void cmdlcd(u8);
void CharLCD(u8);
void InitLCD(void);
void strlcd(char *);
void U32LCD(u32);
void s32lcd(s32);
void f32lcd(f32,u8);
void buildcgram( u8*,u8);

