/* main_delay_test.c*/
#include"delays.h"
main()
{
delay_us(1);
delay_us(100);
delay_us(1000);
delay_us(1000000);
delay_ms(2);
delay_s(5);
while(1);
}
