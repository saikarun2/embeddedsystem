#include<lpc21xx.h>
#include"delays.h"
#include"defines.h"
#include"types.h"
#include"lcd_defines.h"
void writelcd(u8 dat)
{
 SCLRBIT(IOCLR0,LCD_RW);
 WRITEBYTE(IOPIN0,LCD_DATA,dat);
 SSETBIT(IOSET0,LCD_EN);
 delay_us(1);
 SCLRBIT(IOCLR0,LCD_EN);
 delay_ms(2);
 }
void cmdlcd(u8 cmd)
{
 SCLRBIT(IOCLR0,LCD_RS);
 writelcd(cmd);
 }
void CharLCD(u8 ASCIIVAL)
{
 SSETBIT(IOSET0,LCD_RS);
writelcd(ASCIIVAL);
 }
void InitLCD(void)
{
 WRITEBYTE(IODIR0,LCD_DATA,0XFF);
 SETBIT(IODIR0,LCD_RS);
 SETBIT(IODIR0,LCD_RW);
 SETBIT(IODIR0,LCD_EN);


 delay_ms(15);
 cmdlcd(0x30);
 delay_ms(4);
 delay_us(100);
 cmdlcd(0x30);
 delay_us(100);
 cmdlcd(0x30);
 cmdlcd(0x38);
  cmdlcd(0x0E);
 cmdlcd(0x01);
  cmdlcd(0x06);
}
void strlcd(char *s)
{
while(*s)
   CharLCD(*s++);
 }
void U32LCD(u32 n)
{
u8 a[10];
s8 i=0;
if(n==0)
CharLCD('0');
 while(n>0)
 {
 a[i]=(n%10)+48;
 n/=10;
 i++;
 }
 for(--i;i>=0;i--)
 CharLCD(a[i]);
}
void s32lcd(s32 n)
{
if(n>0)
{
CharLCD('_');
 n=-n;
 }
 U32LCD(n);
 }
void f32lcd(f32 f,u8 ndp)
{
u32 n;u8 i;
if(f<0.0)
{
CharLCD('_');
f=-f;
}
n=f;
U32LCD(n);
CharLCD('.');
for(i=0;i<ndp;i++)
{
f=(f-n)*10;
n=f;
CharLCD(n+48);
}
}

void buildcgram( u8* p8,u8 nbytes)
{
u8 i;
cmdlcd(0x40);
for(i=0;i<nbytes;i++)
{
CharLCD(p8[i]);
}
cmdlcd(0x80);
}

