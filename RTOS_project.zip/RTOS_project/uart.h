#include <LPC21XX.H>

//PINSEL0 defines
#define TXD0_EN 1<<0 //PINSEL0 - bit0 & bit1 used for function selection for P0.0
#define RXD0_EN 1<<2 //PINSEL0 - bit2 & bit3 used for function selection for P0.1
//U0LCR defines
#define WORD_LEN_8 0x03
#define STOP_BIT_1 0x00
#define DLAB 7
//U0LSR defines
#define DR_BIT 0
#define TEMT_BIT 6
//DIVISOR defines
#define FOSC 12000000
#define CCLK (5*FOSC)
#define PCLK (CCLK/4)
#define BAUDRATE 9600
#define DIVISOR (PCLK/(16*BAUDRATE))

#define UART_INT_ENABLE 1

//declarations of functions

void UART0_Init(void);
void UART0_Tx_Char(char ch);
char UART0_Rx_Char(void);
void UART0_Tx_Str(char *ptr);
void UART0_isr(void) __irq;
void UART0_Int(unsigned int n);
void UART0_Float(float f);



