#include"esp.h"
extern char buff[200];
extern unsigned char i;

void esp01_connectAP()
{
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd("AT");
	delay_ms(100);
	UART0_Tx_Str("AT\r\n");
	i=0;memset(buff,'\0',200);
	while(i<4);
	delay_ms(100);
	buff[i] = '\0';
    cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd(buff);
	delay_ms(100);
	if(strstr(buff,"OK"))
	{
		cmdlcd(0xC0);
	strlcd("OK");
		delay_ms(100);		
	}
	else
	{
		cmdlcd(0xC0);
		strlcd("ERROR");
		delay_ms(100);		
		return;
	}
	
	
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd("ATE0");
	delay_ms(100);
	UART0_Tx_Str("ATE0\r\n");
	i=0;memset(buff,'\0',200);
	while(i<4);
	delay_ms(100);
	buff[i] = '\0';
    cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd(buff);
	delay_ms(100);
	if(strstr(buff,"OK"))
	{
        cmdlcd(0xC0);
		strlcd("OK");
		delay_ms(100);		
	}
	else
	{
		cmdlcd(0xC0);
		strlcd("ERROR");
		delay_ms(100);		
		return;
	}
	
	
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd("AT+CIPMUX");
	delay_ms(100);
UART0_Tx_Str("AT+CIPMUX=0\r\n");
	i=0;memset(buff,'\0',200);
	while(i<4);
	delay_ms(100);
	buff[i] = '\0';
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd(buff);
	delay_ms(100);
	if(strstr(buff,"OK"))
	{
		cmdlcd(0xC0);
		strlcd("OK");
		delay_ms(100);		
	}
	else
	{
		cmdlcd(0xC0);
		strlcd("ERROR");
		delay_ms(100);		
		return;
	}
	
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd("AT+CWQAP");
	delay_ms(100);
	UART0_Tx_Str("AT+CWQAP\r\n");
	i=0;memset(buff,'\0',200);
	while(i<4);
	delay_ms(100);
	buff[i] = '\0';
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd(buff);
	delay_ms(100);
	if(strstr(buff,"OK"))
	{
		cmdlcd(0xC0);
		strlcd("OK");
		delay_ms(100);		
	}
	else
	{
		cmdlcd(0xC0);
		strlcd("ERROR");
		delay_ms(100);		
		return;
	}
	
	
	
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd("AT+CWJAP");
	delay_ms(100);
	//need to change the wifi network name and password
	UART0_Tx_Str("AT+CWJAP=\"1\",\"teejasv3\"\r\n");
	i=0;memset(buff,'\0',200);
	while(i<4);
	delay_ms(200);
	buff[i] = '\0';
	cmdlcd(0x01);
	cmdlcd(0x80);
strlcd(buff);
	delay_ms(200);
	if(strstr(buff,"WIFI CONNECTED"))
	{
		cmdlcd(0xC0);
		strlcd("OK");
		delay_ms(100);		
	}
	else
	{
		cmdlcd(0xC0);
		strlcd("ERROR");
		delay_ms(100);		
		return;
	}
	
}

/*void esp01_sendToThingspeak(char *val)
{
	cmdlcd(0x01);
	cmdlcd(0x80);
   strlcd("AT+CIPSTART");
	delay_ms(1000);
	UART0_Tx_Str("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n");
	i=0;memset(buff,'\0',200);
	while(i<5);
	delay_ms(2500);
	buff[i] = '\0';
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd(buff);
	delay_ms(2000);
	if(strstr(buff,"CONNECT") || strstr(buff,"ALREADY CONNECTED"))
	{
		cmdlcd(0xC0);
		strlcd("OK");
		delay_ms(1000);
		
		cmdlcd(0x01);
		cmdlcd(0x80);
		strlcd("AT+CIPSEND");
		delay_ms(1000);
	UART0_Tx_Str("AT+CIPSEND=51\r\n");
		i=0;memset(buff,'\0',200);
		//while(buff[i] != '>');
		delay_ms(500);
		//need to change the thingspeak write API key accordind to your channel
		UART0_Tx_Str("GET /update?api_key=PMSMTM72RNBJSXYH&field1=");
		UART0_Tx_Str(val);
	UART0_Tx_Str("\r\n\r\n");
		delay_ms(5000);
		delay_ms(5000);
		buff[i] = '\0';
		cmdlcd(0x01);
		cmdlcd(0x80);
		strlcd(buff);
		delay_ms(2000);
		if(strstr(buff,"SEND OK"))
		{
			cmdlcd(0x01);
			strlcd("DATA UPDATED");
			delay_ms(1000);			
		}
		else
		{
			cmdlcd(0x01);
			strlcd("DATA NOT UPDATED");
			delay_ms(1000);	
		}
		
	}
	else
	{
		cmdlcd(0xC0);
		strlcd("ERROR");
		delay_ms(1000);		
		return;
	}
}
*/
/*
		else if(!strstr(buff,"CLOSED"))
		{
			cmdlcd(0x01);
			cmdlcd(0x80);
			Write_str_LCD("AT+CIPCLOSE");
			delay_ms(1000);
			UART0_Str("AT+CIPCLOSE\r\n");
			i=0;memset(buff,'\0',200);
			while(i<5);
			delay_ms(2500);
			buff[i] = '\0';
			cmdlcd(0x01);
			cmdlcd(0x80);
			Write_str_LCD(buff);
			delay_ms(2000);
			if(strstr(buff,"OK"))
			{
				cmdlcd(0x01);
				cmdlcd(0x80);
				Write_str_LCD("OK");
				delay_ms(2000);				
			}
			else
			{
				cmdlcd(0x01);
				cmdlcd(0x80);
				Write_str_LCD("ERROR");
				delay_ms(2000);		
			}
		
		}*/
void esp01_sendToThingspeak(u32 val)
{
	cmdlcd(0x01);
	cmdlcd(0x80);
   strlcd("AT+CIPSTART");
	delay_ms(10);
	UART0_Tx_Str("AT+CIPSTART=\"TCP\",\"api.thingspeak.com\",80\r\n");
	i=0;memset(buff,'\0',200);
	while(i<5);
	delay_ms(10);
	buff[i] = '\0';
	cmdlcd(0x01);
	cmdlcd(0x80);
	strlcd(buff);
	delay_ms(1);
	if(strstr(buff,"CONNECT") || strstr(buff,"ALREADY CONNECTED"))
	{
		cmdlcd(0xC0);
		strlcd("OK");
		delay_ms(1);
		
		cmdlcd(0x01);
		cmdlcd(0x80);
		strlcd("AT+CIPSEND");
		delay_ms(1);
        if(val>=0 && val<10)
            UART0_Tx_Str("AT+CIPSEND=49\r\n");
        else if(val>=10 && val<100) 
            UART0_Tx_Str("AT+CIPSEND=50\r\n");
        else if(val>=100 && val<1000)
            UART0_Tx_Str("AT+CIPSEND=51\r\n");
		i=0;memset(buff,'\0',200);
		//while(buff[i] != '>');
		delay_ms(2);
		//need to change the thingspeak write API key accordind to your channel
		UART0_Tx_Str("GET /update?api_key=YQXK5GNH47FHROSN&field1=");
        UART0_Int(val);
        UART0_Tx_Str("\r\n\r\n");
		delay_ms(5);
		//delay_ms(5000);
		buff[i] = '\0';
		cmdlcd(0x01);
		cmdlcd(0x80);
		strlcd(buff);
		delay_ms(2);
		if(strstr(buff,"SEND OK"))
		{
			cmdlcd(0x01);
			strlcd("DATA UPDATED");
			delay_ms(1);			
		}
		else
		{
			cmdlcd(0x01);
			strlcd("DATA NOT UPDATED");
			delay_ms(1);	
		}
		
	}
	else
	{
		cmdlcd(0xC0);
		strlcd("ERROR");
		delay_ms(10);		
		return;
	}
}
