#include <string.h>
#include "uart.h"
#include "delays.h"
#include "lcd_defines.h"
#include "types.h"

void esp01_connectAP(void);
void esp01_sendToThingspeak(u32 val);
