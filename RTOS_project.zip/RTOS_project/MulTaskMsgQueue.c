

/*----------------------------------------------------------------------------
 *   Task 1:  RTX Kernel starts this task with os_sys_init (task1)
 *---------------------------------------------------------------------------*/
__task void task1 (void) 
{
	unsigned char RxChar=0;

	MSG_QUEUE *sendptr;

	/* Obtain own system task identification number */
  id1 = os_tsk_self ();
  /* Assign system identification number of task2 to id2 */
  id2 = os_tsk_create (task2, 1);
  os_mbx_init (MsgQueue, sizeof(MsgQueue));/* initialize the mailbox             */

	for (;;) 
	{
//		RxChar=UART0_Rx_char();
//		if(RxChar=='A')
	  {
			sendptr = _alloc_box (mpool);          /* Allocate a memory for the message   */
			sendptr->msgid=1;
			sendptr->i=RxChar; 
			os_mbx_send (MsgQueue, sendptr, 0xffff); /* Send the message to the mailbox     */
		
		}
		os_dly_wait (100);//wait on timer for 100 tick=100*10ms=1000ms

	}
}
/*----------------------------------------------------------------------------
 *   Task 2:  RTX Kernel starts this task with os_tsk_create (task2, 1)
 *---------------------------------------------------------------------------*/
__task void task2 (void) 
{
	MSG_QUEUE *recvptr;
	for (;;) 
	{
	
	//	UART0_Tx_str("waiting for message...\r\n");
    os_mbx_wait(MsgQueue, (void **)&recvptr, 0xffff); /* wait for the message    */
    	UART0_Tx_str("Got Message with a msg id : ");
		UART0_Tx_int(recvptr->msgid);
	  UART0_Tx_str("\r\n Rxed Data is  : ");
		UART0_Tx_int(recvptr->i);
   UART0_Tx_str("\r\n");
		_free_box(mpool, recvptr);     // free memory allocated for message  */
  	
		os_dly_wait(100);//wait on timer for 100 tick=100*10ms=1000ms
  }
}


